#!/usr/bin/python

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import json


SLO_MS = 100


def load_latency(filename):
    with open(filename) as manager_log_file:
        lines = manager_log_file.readlines()
        lines = [x for x in lines if "FINE Time" in x]
        latencies = [x.split("req: ", 1)[1].split(";", 1)[0] for x in lines]
        return np.array([float(x) / 1000 for x in latencies])


hi_gv    = load_latency("hi/gv_manager.log")
# hi_gv_si = load_latency("hi/gv-si_manager.log")
hi_kn    = load_latency("hi/kn_manager.log")
hi_gv_fc = load_latency("hi/gv-fc_manager.log")
hi_ow    = load_latency("hi/ow_manager.log")

hi_slo_gv    = (np.sum(hi_gv > 100) / len(hi_gv)) * 100
# # # hi_slo_gv_si = (np.sum(hi_gv_si > 100) / len(hi_gv_si)) * 100
hi_slo_kn =    (np.sum(hi_kn > 100) / len(hi_kn)) * 100
hi_slo_gv_fc = (np.sum(hi_gv_fc > 100) / len(hi_gv_fc)) * 100
hi_slo_ow    = (np.sum(hi_ow > 100) / len(hi_ow)) * 100

print("FOR HI DIVERSITY (Node#2)")

print(f"{hi_slo_gv:.2f}% in GV violate.")
# print(f"{hi_slo_gv_si:.2f}% in GV SI violate.")
print(f"{hi_slo_kn:.2f}% in KN violate.")
print(f"{hi_slo_gv_fc:.2f}% in GV FC violate.")
print(f"{hi_slo_ow:.2f}% in OW violate.")

lo_gv    = load_latency("lo/gv_manager.log")
# lo_gv_si = load_latency("lo/gv-si_manager.log")
lo_kn    = load_latency("lo/kn_manager.log")
lo_gv_fc = load_latency("lo/gv-fc_manager.log")
lo_ow    = load_latency("lo/ow_manager.log")

lo_slo_gv    = (np.sum(lo_gv > 100) / len(lo_gv)) * 100
# # # lo_slo_gv_si = (np.sum(lo_gv_si > 100) / len(lo_gv_si)) * 100
lo_slo_kn =    (np.sum(lo_kn > 100) / len(lo_kn)) * 100
lo_slo_gv_fc = (np.sum(lo_gv_fc > 100) / len(lo_gv_fc)) * 100
lo_slo_ow    = (np.sum(lo_ow > 100) / len(lo_ow)) * 100

print("FOR LO DIVERSITY (Node#1)")

print(f"{lo_slo_gv:.2f}% in GV violate.")
# print(f"{lo_slo_gv_si:.2f}% in GV SI violate.")
print(f"{lo_slo_kn:.2f}% in KN violate.")
print(f"{lo_slo_gv_fc:.2f}% in GV FC violate.")
print(f"{lo_slo_ow:.2f}% in OW violate.")

