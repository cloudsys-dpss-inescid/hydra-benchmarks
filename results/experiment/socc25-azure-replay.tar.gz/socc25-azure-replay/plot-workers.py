#!/usr/bin/python

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import json
import statistics


def load_data(filename):
    with open(filename) as log_file:
        lines = log_file.readlines()
        invocations = [int(x.split(' ')[-1]) for x in lines if "Total requests:" in x]
        functions = [int(x.split(' ')[-1]) for x in lines if "Registered functions:" in x]
        owners = [int(x.split(' ')[-1]) for x in lines if "Registered owners:" in x]
        return invocations, functions, owners


def numpy_ewma_vectorized(data, window):
    alpha = 2 /(window + 1.0)
    alpha_rev = 1-alpha

    scale = 1/alpha_rev
    n = data.shape[0]

    r = np.arange(n)
    scale_arr = scale**r
    offset = data[0]*alpha_rev**(r+1)
    pw0 = alpha*alpha_rev**(n-1)

    mult = data*pw0*scale_arr
    cumsums = mult.cumsum()
    out = offset + cumsums*scale_arr[::-1]
    return out


invocations, functions, owners = load_data("hi/lse_executor.log")

# invocations = numpy_ewma_vectorized(np.array(invocations), 10)
# functions = numpy_ewma_vectorized(np.array(functions), 10)
# owners = numpy_ewma_vectorized(np.array(owners), 10)

x = np.arange(1, len(invocations) + 1)

matplotlib.rcParams.update({'font.size': 16})
plt.rcParams["figure.figsize"] = (10, 4)
plt.plot(x, invocations,                   linewidth = 3, label = "Invocations")
plt.plot(x, functions,   linestyle = ":",  linewidth = 3, label = "Functions")
plt.plot(x, owners,      linestyle = "--", linewidth = 3, label = "Tenants")
plt.xlabel("Node Index")
plt.ylabel("Served")
plt.yscale('log')
plt.xlim(xmin=0, xmax=100)
plt.ylim(ymin=0, ymax=10000000)
plt.grid()
plt.legend(ncol=3, loc='upper right')
# plt.tight_layout()
plt.savefig("workers.pdf", bbox_inches="tight")
plt.savefig("workers.png", dpi=300, bbox_inches="tight")
plt.show()
