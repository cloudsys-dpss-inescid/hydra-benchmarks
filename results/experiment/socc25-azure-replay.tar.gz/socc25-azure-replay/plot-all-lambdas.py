#!/usr/bin/python

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import json
    

def numpy_ewma_vectorized(data, window):
    alpha = 2 /(window + 1.0)
    alpha_rev = 1-alpha

    scale = 1/alpha_rev
    n = data.shape[0]

    r = np.arange(n)
    scale_arr = scale**r
    offset = data[0]*alpha_rev**(r+1)
    pw0 = alpha*alpha_rev**(n-1)

    mult = data*pw0*scale_arr
    cumsums = mult.cumsum()
    out = offset + cumsums*scale_arr[::-1]
    return out


def load_lambdas(filename):
    with open(filename) as metrics_file:
        dataset = json.load(metrics_file)

        # Find index of first non-zero active_lambdas
        start_index = next((i for i, x in enumerate(dataset) if x["active_lambdas"] > 0), 0)
        print("Start index (where we started using lambdas): " + str(start_index))
        dataset = dataset[start_index:]

        timestamps = [x["timestamp"] / 1000 / 60 for x in dataset]
        active_lambdas = [min(x["active_lambdas"], 104) for x in dataset]

        first_ts = timestamps[0]
        timestamps = [x - first_ts for x in timestamps]
        return [timestamps, active_lambdas]


hi_gv    = load_lambdas("hi/gv_metrics.log")
# hi_gv_si = load_lambdas("hi/gv-si_metrics.log")
hi_kn    = load_lambdas("hi/kn_metrics.log")
hi_gv_fc = load_lambdas("hi/gv-fc_metrics.log")
hi_ow    = load_lambdas("hi/ow_metrics.log")

hi_gv[1]    = numpy_ewma_vectorized(np.array(hi_gv[1]),    100)
# # hi_gv_si[1] = numpy_ewma_vectorized(np.array(hi_gv_si[1]), 100)
hi_kn[1]    = numpy_ewma_vectorized(np.array(hi_kn[1]), 100)
hi_gv_fc[1] = numpy_ewma_vectorized(np.array(hi_gv_fc[1]), 100)
hi_ow[1]    = numpy_ewma_vectorized(np.array(hi_ow[1]),    100)


lo_gv    = load_lambdas("lo/gv_metrics.log")
# lo_gv_si = load_lambdas("lo/gv-si_metrics.log")
lo_kn    = load_lambdas("lo/kn_metrics.log")
lo_gv_fc = load_lambdas("lo/gv-fc_metrics.log")
lo_ow    = load_lambdas("lo/ow_metrics.log")

lo_gv[1]    = numpy_ewma_vectorized(np.array(lo_gv[1]),    100)
# # lo_gv_si[1] = numpy_ewma_vectorized(np.array(lo_gv_si[1]), 100)
lo_kn[1]    = numpy_ewma_vectorized(np.array(lo_kn[1]), 100)
lo_gv_fc[1] = numpy_ewma_vectorized(np.array(lo_gv_fc[1]), 100)
lo_ow[1]    = numpy_ewma_vectorized(np.array(lo_ow[1]),    100)

matplotlib.rcParams.update({'font.size': 16})
fig, (ax1, ax2) = plt.subplots(1, 2, sharey=True)

ax1.plot(lo_ow[0],    lo_ow[1],    linestyle = "-", marker = "|", markersize = 10, markevery=500, linewidth = 3, label = "OpenWhisk")
# # ax1.plot(lo_gv_si[0], lo_gv_si[1], linestyle = ":",                                              linewidth = 3, label = "Hydra SI")
ax1.plot(lo_kn[0], lo_kn[1], linestyle = "--",                                             linewidth = 3, label = "Knative")
ax1.plot(lo_gv[0],    lo_gv[1],    linestyle = "-", marker = "x", markersize = 10, markevery=500, linewidth = 3, label = "Hydra")
ax1.plot(lo_gv_fc[0], lo_gv_fc[1], linestyle = "--",                                              linewidth = 3, label = "Hydra*")
ax1.set_xlabel("Node #1")
ax1.set_ylim(ymin=0, ymax=120)
ax1.set_xlim(xmin=0, xmax=30)
ax1.set_ylabel("Number of Instances")
ax1.grid()
# ax1.legend(ncol=2, loc='lower right')

ax2.plot(hi_ow[0],    hi_ow[1],    linestyle = "-", marker = "|", markersize = 10, markevery=500, linewidth = 3, label = "OpenWhisk")
# # ax2.plot(hi_gv_si[0], hi_gv_si[1], linestyle = ":",                                              linewidth = 3, label = "Hydra SI")
ax2.plot(hi_kn[0], hi_kn[1], linestyle = "--",                                             linewidth = 3, label = "Knative")
ax2.plot(hi_gv[0],    hi_gv[1],    linestyle = "-", marker = "x", markersize = 10, markevery=500, linewidth = 3, label = "Hydra")
ax2.plot(hi_gv_fc[0], hi_gv_fc[1], linestyle = "--",                                              linewidth = 3, label = "Hydra*")
ax2.set_xlabel("Node #2")
ax2.set_ylim(ymin=0, ymax=120)
ax2.set_xlim(xmin=0, xmax=30)
ax2.grid()
ax2.legend(ncol=1, loc='center right')

fig.set_figwidth(10)
fig.set_figheight(4)

fig.text(0.5, -0.02, 'Time (min)', ha='center')

plt.savefig("lambdas.pdf", bbox_inches="tight")
plt.savefig("lambdas.png", dpi=300, bbox_inches="tight")
# plt.show()
