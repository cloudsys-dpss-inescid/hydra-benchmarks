#!/bin/bash

function DIR {
    echo "$(cd "$(dirname "${BASH_SOURCE[0]}")" &>/dev/null && pwd)"
}


# Copy result files.
scp sergiyivan@vitamina02:/tmp/lse_executor.log  $(DIR)/lse_executor.log
scp sergiyivan@vitamina02:/tmp/lse_trace.csv  $(DIR)/lse_trace.csv

scp sergiyivan@vitamina03:/tmp/lse-results/*.log $(DIR)
