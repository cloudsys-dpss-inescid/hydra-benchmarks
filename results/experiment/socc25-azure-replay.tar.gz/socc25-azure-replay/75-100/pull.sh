#!/bin/bash

function DIR {
    echo "$(cd "$(dirname "${BASH_SOURCE[0]}")" &>/dev/null && pwd)"
}

MODE=$1

# Copy result files.
# scp sergiyivan@vitamina03:/home/sergiyivan/lse/argo/argo/lambda-manager/manager_metrics/metrics.log      $(DIR)/"$MODE"_metrics.log
# scp sergiyivan@vitamina03:/home/sergiyivan/lse/argo/argo/lambda-manager/manager_logs/lambda_manager.log  $(DIR)/"$MODE"_manager.log

scp sergiyivan@vitamina02:/tmp/lse_executor.log  $(DIR)/lse_executor.log
scp sergiyivan@vitamina02:/tmp/lse_trace.csv  $(DIR)/lse_trace.csv

for mode in gv-fc gv-si gv kn ow
do
    res=$(ssh sergiyivan@vitamina03 'cat /tmp/lse-results/'$mode'_manager.log | grep "The lambda pool is currently empty" | wc -l')
    echo "Lambda pool missed in $mode: $res"
    ssh sergiyivan@vitamina03 'sed -i "/The lambda pool is currently empty/d" /tmp/lse-results/'$mode'_manager.log'

    scp sergiyivan@vitamina03:/tmp/lse-results/"$mode"_metrics.log  $(DIR)/"$mode"_metrics.log
    scp sergiyivan@vitamina03:/tmp/lse-results/"$mode"_manager.log  $(DIR)/"$mode"_manager.log
done
