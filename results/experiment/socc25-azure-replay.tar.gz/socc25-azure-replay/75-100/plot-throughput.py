#!/usr/bin/python

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import json


def load_tput(filename):
    with open(filename) as metrics_file:
        dataset = json.load(metrics_file)
        timestamps = [x["timestamp"] / 1000 for x in dataset]
        tput = [x["throughput"] for x in dataset]
        return [timestamps, tput]
    

def numpy_ewma_vectorized(data, window):
    alpha = 2 /(window + 1.0)
    alpha_rev = 1-alpha

    scale = 1/alpha_rev
    n = data.shape[0]

    r = np.arange(n)
    scale_arr = scale**r
    offset = data[0]*alpha_rev**(r+1)
    pw0 = alpha*alpha_rev**(n-1)

    mult = data*pw0*scale_arr
    cumsums = mult.cumsum()
    out = offset + cumsums*scale_arr[::-1]
    return out

gv    = load_tput("gv_metrics.log")
gv_sf    = load_tput("gv-sf_metrics.log")
gv_si    = load_tput("gv-si_metrics.log")
ow    = load_tput("ow_metrics.log")

gv[1]    = numpy_ewma_vectorized(np.array(gv[1]),    10)
gv_sf[1]    = numpy_ewma_vectorized(np.array(gv_sf[1]),    10)
gv_si[1]    = numpy_ewma_vectorized(np.array(gv_si[1]),    10)
ow[1]    = numpy_ewma_vectorized(np.array(ow[1]),    10)


matplotlib.rcParams.update({'font.size': 16})
plt.rcParams["figure.figsize"] = (10, 4)
plt.plot(gv[0],    gv[1],    linestyle = "-",                                               linewidth = 3, label = "Hydra")
plt.plot(gv_sf[0],    gv_sf[1],    linestyle = "--",                                               linewidth = 3, label = "Hydra-SF")
plt.plot(gv_si[0],    gv_si[1],    linestyle = ":",                                               linewidth = 3, label = "Hydra-SI")
plt.plot(ow[0],    ow[1],    linestyle = "-",                                               linewidth = 3, label = "OpenWhisk")
plt.xlabel("Time (s)")
plt.ylabel("Throughput (ops/s)")
plt.grid()
plt.ylim(ymin=0)
plt.xlim(xmin=0)
plt.legend(ncol=2, loc='lower center')
plt.tight_layout()
# plt.savefig("throughput.pdf")
plt.savefig("throughput.png", dpi=300, bbox_inches="tight")
plt.show()
