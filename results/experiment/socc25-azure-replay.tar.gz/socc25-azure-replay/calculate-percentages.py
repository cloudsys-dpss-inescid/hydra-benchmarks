#!/usr/bin/python

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import json
    

def numpy_ewma_vectorized(data, window):
    alpha = 2 /(window + 1.0)
    alpha_rev = 1-alpha

    scale = 1/alpha_rev
    n = data.shape[0]

    r = np.arange(n)
    scale_arr = scale**r
    offset = data[0]*alpha_rev**(r+1)
    pw0 = alpha*alpha_rev**(n-1)

    mult = data*pw0*scale_arr
    cumsums = mult.cumsum()
    out = offset + cumsums*scale_arr[::-1]
    return out


def load_memory(filename):
    with open(filename) as metrics_file:
        dataset = json.load(metrics_file)
        system_footprints = [x["system_footprint"] / 1000 for x in dataset]
        return system_footprints[90:][:3600]


# Loading memory and converting from MBs to GBs
hi_gv_fc    = load_memory("hi/gv-fc_metrics.log")
hi_gv    = load_memory("hi/gv_metrics.log")
hi_ow    = load_memory("hi/ow_metrics.log")
hi_kn    = load_memory("hi/kn_metrics.log")
# hi_gv_fc    = numpy_ewma_vectorized(np.array(hi_gv_fc), 500)
# hi_ow    = numpy_ewma_vectorized(np.array(hi_ow), 500)

lo_gv_fc    = load_memory("lo/gv-fc_metrics.log")
lo_gv    = load_memory("lo/gv_metrics.log")
lo_ow    = load_memory("lo/ow_metrics.log")
lo_kn    = load_memory("lo/kn_metrics.log")
# lo_gv_fc    = numpy_ewma_vectorized(np.array(lo_gv_fc), 500)
# lo_ow    = numpy_ewma_vectorized(np.array(lo_ow), 500)

perc = 100 - ((np.mean(lo_gv_fc) * 100) / np.mean(lo_ow))
print("Footprint Hydra-FC compared to OW in Node #1 got improved by (percent):")
print(perc)
times = np.mean(lo_ow) / np.mean(lo_gv_fc)
print("Footprint Hydra-FC compared to OW in Node #1 got improved by:")
print(times)
perc = 100 - ((np.mean(hi_gv_fc) * 100) / np.mean(hi_ow))
print("Footprint Hydra-FC compared to OW in Node #2 got improved by (percent):")
print(perc)
times = np.mean(hi_ow) / np.mean(hi_gv_fc)
print("Footprint Hydra-FC compared to OW in Node #2 got improved by:")
print(times)

print("------------------------------")

perc = 100 - ((np.mean(lo_gv) * 100) / np.mean(lo_ow))
print("Footprint Hydra compared to OW in Node #1 got improved by (percent):")
print(perc)
times = np.mean(lo_ow) / np.mean(lo_gv)
print("Footprint Hydra compared to OW in Node #1 got improved by:")
print(times)
perc = 100 - ((np.mean(hi_gv) * 100) / np.mean(hi_ow))
print("Footprint Hydra compared to OW in Node #2 got improved by (percent):")
print(perc)
times = np.mean(hi_ow) / np.mean(hi_gv)
print("Footprint Hydra compared to OW in Node #2 got improved by:")
print(times)

print("---------------------------------------------------------------------")

perc = 100 - ((np.mean(lo_gv_fc) * 100) / np.mean(lo_kn))
print("Footprint Hydra-FC compared to Knative in Node #1 got improved by (percent):")
print(perc)
times = np.mean(lo_kn) / np.mean(lo_gv_fc)
print("Footprint Hydra-FC compared to Knative in Node #1 got improved by:")
print(times)
perc = 100 - ((np.mean(hi_gv_fc) * 100) / np.mean(hi_kn))
print("Footprint Hydra-FC compared to Knative in Node #2 got improved by (percent):")
print(perc)
times = np.mean(hi_kn) / np.mean(hi_gv_fc)
print("Footprint Hydra-FC compared to Knative in Node #2 got improved by:")
print(times)

print("------------------------------")

perc = 100 - ((np.mean(lo_gv) * 100) / np.mean(lo_kn))
print("Footprint Hydra compared to Knative in Node #1 got improved by (percent):")
print(perc)
times = np.mean(lo_kn) / np.mean(lo_gv)
print("Footprint Hydra compared to Knative in Node #1 got improved by:")
print(times)
perc = 100 - ((np.mean(hi_gv) * 100) / np.mean(hi_kn))
print("Footprint Hydra compared to Knative in Node #2 got improved by (percent):")
print(perc)
times = np.mean(hi_kn) / np.mean(hi_gv)
print("Footprint Hydra compared to Knative in Node #2 got improved by:")
print(times)
