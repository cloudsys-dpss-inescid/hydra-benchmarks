#!/usr/bin/python

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import json


def load_latency(filename):
    with open(filename) as manager_log_file:
        lines = manager_log_file.readlines()
        lines = [x for x in lines if "FINE Time" in x]
        latencies = [x.split("req: ", 1)[1].split(";", 1)[0] for x in lines]
        return [float(x) / 1000 for x in latencies]


hi_gv    = load_latency("hi/gv_manager.log")
# hi_gv_si = load_latency("hi/gv-si_manager.log")
hi_kn    = load_latency("hi/kn_manager.log")
hi_gv_fc = load_latency("hi/gv-fc_manager.log")
hi_ow    = load_latency("hi/ow_manager.log")

hi_x_gv    = np.sort(hi_gv)
# # hi_x_gv_si = np.sort(hi_gv_si)
hi_x_kn    = np.sort(hi_kn)
hi_x_gv_fc = np.sort(hi_gv_fc)
hi_x_ow    = np.sort(hi_ow)

hi_y_gv    = np.arange(len(hi_gv))    / float(len(hi_gv))
# # # hi_y_gv_si = np.arange(len(hi_gv_si)) / float(len(hi_gv_si))
hi_y_kn    = np.arange(len(hi_kn)) / float(len(hi_kn))
hi_y_gv_fc = np.arange(len(hi_gv_fc)) / float(len(hi_gv_fc))
hi_y_ow    = np.arange(len(hi_ow))    / float(len(hi_ow))

lo_gv    = load_latency("lo/gv_manager.log")
# lo_gv_si = load_latency("lo/gv-si_manager.log")
lo_kn    = load_latency("lo/kn_manager.log")
lo_gv_fc = load_latency("lo/gv-fc_manager.log")
lo_ow    = load_latency("lo/ow_manager.log")

lo_x_gv    = np.sort(lo_gv)
# # lo_x_gv_si = np.sort(lo_gv_si)
lo_x_kn    = np.sort(lo_kn)
lo_x_gv_fc = np.sort(lo_gv_fc)
lo_x_ow    = np.sort(lo_ow)

lo_y_gv    = np.arange(len(lo_gv))    / float(len(lo_gv))
# # # lo_y_gv_si = np.arange(len(lo_gv_si)) / float(len(lo_gv_si))
lo_y_kn    = np.arange(len(lo_kn)) / float(len(lo_kn))
lo_y_gv_fc = np.arange(len(lo_gv_fc)) / float(len(lo_gv_fc))
lo_y_ow    = np.arange(len(lo_ow))    / float(len(lo_ow))

matplotlib.rcParams.update({'font.size': 16})

fig, (ax1, ax2) = plt.subplots(2, 1, sharex=True)

ax1.plot(lo_x_ow,    lo_y_ow,    linestyle = "-", marker = "|", markersize = 10, markevery=5000, linewidth = 3, label = "OpenWhisk")
# # ax1.plot(lo_x_gv_si, lo_y_gv_si, linestyle = ":",                                              linewidth = 3, label = "Hydra SI")
ax1.plot(lo_x_kn, lo_y_kn, linestyle = "--",                                             linewidth = 3, label = "Knative")
ax1.plot(lo_x_gv,    lo_y_gv,    linestyle = "-", marker = "x", markersize = 10, markevery=5000, linewidth = 3, label = "Hydra")
ax1.plot(lo_x_gv_fc, lo_y_gv_fc, linestyle = "--",                                              linewidth = 3, label = "Hydra*")
ax1.set_ylabel("CDF")
ax1.set_xscale('log')
ax1.set_ylim(ymin=0.9, ymax=1)
ax1.set_xlim(xmin=0)#, xmax=80000)
ax1.grid()
# ax1.legend(ncol=2, loc='lower right')

ax2.plot(hi_x_ow,    hi_y_ow,    linestyle = "-", marker = "|", markersize = 10, markevery=50000, linewidth = 3, label = "OpenWhisk")
# # ax2.plot(hi_x_gv_si, hi_y_gv_si, linestyle = ":",                                              linewidth = 3, label = "Hydra SI")
ax2.plot(hi_x_kn, hi_y_kn, linestyle = "--",                                             linewidth = 3, label = "Knative")
ax2.plot(hi_x_gv,    hi_y_gv,    linestyle = "-", marker = "x", markersize = 10, markevery=50000, linewidth = 3, label = "Hydra")
ax2.plot(hi_x_gv_fc, hi_y_gv_fc, linestyle = "--",                                              linewidth = 3, label = "Hydra*")
ax2.set_xlabel("Request Latency (ms)")
ax2.set_ylabel("CDF")
ax2.set_xscale('log')
ax2.set_ylim(ymin=0.9, ymax=1)
ax2.set_xlim(xmin=0)#, xmax=80000)
ax2.grid()

fig.set_figwidth(10)
fig.set_figheight(4)

fig.text(0.177, 0.8, 'Node #1', ha='center')
fig.text(0.177, 0.37, 'Node #2', ha='center')

plt.savefig("latency.pdf", bbox_inches="tight")
plt.savefig("latency.png", dpi=300, bbox_inches="tight")
# plt.show()

p99_gv    = np.percentile(lo_gv, 99)
p99_kn    = np.percentile(lo_kn, 99)
p99_gv_fc = np.percentile(lo_gv_fc, 99)
p99_ow    = np.percentile(lo_ow, 99)
print("99p improvement for Node #1:")
print("Hydra / Knative      :", p99_kn / p99_gv)
print("Hydra* / Knative     :", p99_kn / p99_gv_fc)
print("Hydra / OW           :", p99_ow / p99_gv)
print("Hydra* / OW          :", p99_ow / p99_gv_fc)

p99_gv    = np.percentile(hi_gv, 99)
p99_kn    = np.percentile(hi_kn, 99)
p99_gv_fc = np.percentile(hi_gv_fc, 99)
p99_ow    = np.percentile(hi_ow, 99)
print("99p improvement for Node #2:")
print("Hydra / Knative      :", p99_kn / p99_gv)
print("Hydra* / Knative     :", p99_kn / p99_gv_fc)
print("Hydra / OW           :", p99_ow / p99_gv)
print("Hydra* / OW          :", p99_ow / p99_gv_fc)
