#!/usr/bin/python

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import json


def load_memory(filename):
    with open(filename) as metrics_file:
        dataset = json.load(metrics_file)
        timestamps = [x["timestamp"] / 1000 for x in dataset]
        system_footprints = [x["graalos_memory"] / 1000 for x in dataset]
        return [timestamps, system_footprints]


# Loading memory and converting from MBs to GBs
gos    = load_memory("gos_metrics.log")

matplotlib.rcParams.update({'font.size': 16})
plt.rcParams["figure.figsize"] = (10, 4)
plt.plot(gos[0],    gos[1],    linestyle = ":",                                               linewidth = 3, label = "GraalOS")
plt.xlabel("Time (s)")
plt.ylabel("GraalOS Footprint (GBs)")
plt.grid()
# plt.yscale('log')
plt.xlim(xmin=0)
plt.legend(ncol=2, loc='lower center')
plt.tight_layout()
# plt.savefig("gos-rss.pdf")
plt.savefig("gos-rss.png", dpi=300, bbox_inches="tight")
plt.show()
