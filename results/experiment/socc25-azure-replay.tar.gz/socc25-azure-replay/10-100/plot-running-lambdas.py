#!/usr/bin/python

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import json


def load_lambdas(filename):
    with open(filename) as metrics_file:
        dataset = json.load(metrics_file)
        timestamps = [x["timestamp"] / 1000 for x in dataset]
        active_lambdas = [x["active_lambdas_running"] for x in dataset]
        return [timestamps, active_lambdas]


gv    = load_lambdas("gv_metrics.log")
gv_sf    = load_lambdas("gv-sf_metrics.log")
gv_si    = load_lambdas("gv-si_metrics.log")
ow    = load_lambdas("ow_metrics.log")

matplotlib.rcParams.update({'font.size': 16})
plt.rcParams["figure.figsize"] = (10, 4)
plt.plot(gv[0],    gv[1],    linestyle = "-",                                               linewidth = 3, label = "Hydra")
plt.plot(gv_sf[0],    gv_sf[1],    linestyle = "--",                                               linewidth = 3, label = "Hydra-SF")
plt.plot(gv_si[0],    gv_si[1],    linestyle = ":",                                               linewidth = 3, label = "Hydra-SI")
plt.plot(ow[0],    ow[1],    linestyle = "-",                                               linewidth = 3, label = "OpenWhisk")
plt.xlabel("Time (s)")
plt.ylabel("Number of Instances Running Invocations")
# plt.yscale('log')
plt.grid()
# plt.xlim(xmin=0, xmax=1200)
plt.legend(ncol=2, loc='lower center')
plt.tight_layout()
# plt.savefig("lambdas-running.pdf")
plt.savefig("lambdas-running.png", dpi=300, bbox_inches="tight")
plt.show()
