#!/usr/bin/python

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import json


def load_memory(filename):
    with open(filename) as metrics_file:
        dataset = json.load(metrics_file)
        timestamps = [x["timestamp"] / 1000 for x in dataset]
        system_footprints = [x["system_footprint"] / 1000 for x in dataset]
        return [timestamps, system_footprints]


# Loading memory and converting from MBs to GBs
gv    = load_memory("gv_metrics.log")
gv_sf    = load_memory("gv-sf_metrics.log")
gv_si    = load_memory("gv-si_metrics.log")
ow    = load_memory("ow_metrics.log")

matplotlib.rcParams.update({'font.size': 16})
plt.rcParams["figure.figsize"] = (10, 4)
plt.plot(gv[0],    gv[1],    linestyle = ":",                                               linewidth = 3, label = "Hydra")
plt.plot(gv_sf[0],    gv_sf[1],    linestyle = ":",                                               linewidth = 3, label = "Hydra-SF")
plt.plot(gv_si[0],    gv_si[1],    linestyle = ":",                                               linewidth = 3, label = "Hydra-SI")
plt.plot(ow[0],    ow[1],    linestyle = ":",                                               linewidth = 3, label = "OpenWhisk")
plt.xlabel("Time (s)")
plt.ylabel("System Footprint (GBs)")
plt.grid()
# plt.yscale('log')
plt.xlim(xmin=0)
plt.legend(ncol=2, loc='lower center')
plt.tight_layout()
# plt.savefig("memory.pdf")
plt.savefig("memory.png", dpi=300, bbox_inches="tight")
plt.show()
