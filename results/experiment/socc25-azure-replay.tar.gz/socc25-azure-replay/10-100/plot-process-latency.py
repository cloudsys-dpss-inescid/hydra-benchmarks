#!/usr/bin/python

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import json


def load_latency(filename):
    with open(filename) as manager_log_file:
        lines = manager_log_file.readlines()
        lines = [x for x in lines if "Actual process time" in x]
        latencies = [x.split()[6] for x in lines]
        return [float(x) / 1000 for x in latencies]


gos    = load_latency("gos_manager.log")

x_gos    = np.sort(gos)

y_gos    = np.arange(len(gos)) / float(len(gos))

matplotlib.rcParams.update({'font.size': 16})
plt.rcParams["figure.figsize"] = (10, 4)
plt.plot(x_gos,    y_gos,    linestyle = ":",                                               linewidth = 3, label = "GraalOS")
plt.xscale('log')
plt.ylim(ymin=0, ymax=1)
plt.xlim(xmin=0, xmax=1000)
plt.xlabel("Request Process Latency (ms)")
plt.ylabel("CDF")
plt.grid()
plt.legend(ncol=2, loc='lower right')
plt.tight_layout()
# plt.savefig("process-latency.pdf")
plt.savefig("process-latency.png", dpi=300, bbox_inches="tight")
plt.show()
