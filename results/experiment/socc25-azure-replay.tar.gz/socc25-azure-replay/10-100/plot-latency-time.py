#!/usr/bin/python

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import json
import statistics


def sliding_window(input, window_size, aggregator):
    x = input[0]
    y = input[1]
    res_x = []
    res_y = []
    for i in range(len(x) - window_size + 1):
        res_x.append(x[i])
        res_y.append(aggregator(y[i:i+window_size]))
    return [res_x, res_y]


def load_latency(filename):
    with open(filename) as manager_log_file:
        lines = manager_log_file.readlines()
        lines = [x for x in lines if "FINE Time" in x]
        timestamps = [int(x.split(' ')[1][1:-1]) for x in lines]
        latencies = [x.split("req: ", 1)[1].split(";", 1)[0] for x in lines]
        return [[x/1000 for x in timestamps], [float(x) / 1000 for x in latencies]]


gv    = load_latency("gv_manager.log")
gv_sf    = load_latency("gv-sf_manager.log")
gv_si    = load_latency("gv-si_manager.log")
ow    = load_latency("ow_manager.log")
# gos    = sliding_window(gos,    1000, statistics.mean)
x_gv    = gv[0]
y_gv    = gv[1]

x_gv_sf    = gv_sf[0]
y_gv_sf    = gv_sf[1]

x_gv_si    = gv_si[0]
y_gv_si    = gv_si[1]

x_ow    = ow[0]
y_ow    = ow[1]

matplotlib.rcParams.update({'font.size': 16})
plt.rcParams["figure.figsize"] = (10, 4)
plt.plot(x_gv,    y_gv,    linestyle = "-",                                               linewidth = 3, label = "Hydra")
plt.plot(x_gv_sf,    y_gv_sf,    linestyle = "--",                                               linewidth = 3, label = "Hydra")
plt.plot(x_gv_si,    y_gv_si,    linestyle = ":",                                               linewidth = 3, label = "Hydra")
plt.plot(x_ow,    y_ow,    linestyle = "-",                                               linewidth = 3, label = "OpenWhisk")
plt.ylim(ymin=0)
plt.xlim(xmin=0)
plt.xlabel("Time (s)")
plt.ylabel("User Request Latency (ms)")
plt.grid()
plt.legend(ncol=2, loc='upper center')
plt.tight_layout()
# plt.savefig("latency-time.pdf")
plt.savefig("latency-time.png", dpi=300, bbox_inches="tight")
plt.show()
