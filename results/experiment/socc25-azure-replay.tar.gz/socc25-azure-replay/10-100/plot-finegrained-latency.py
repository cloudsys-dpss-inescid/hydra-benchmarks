#!/usr/bin/python

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import json
import statistics

STRT_IDX = 1
RECV_IDX = 2
RESP_IDX = 3
FINI_IDX = 4

def sliding_window(input, window_size, aggregator):
    x = input[0]
    y_1 = input[1]
    y_2 = input[2]
    y_3 = input[3]
    y_4 = input[4]
    res_x = []
    res_y_1 = []
    res_y_2 = []
    res_y_3 = []
    res_y_4 = []
    for i in range(len(x) - window_size + 1):
        res_x.append(x[i])
        res_y_1.append(aggregator(y_1[i:i+window_size]))
        res_y_2.append(aggregator(y_2[i:i+window_size]))
        res_y_3.append(aggregator(y_3[i:i+window_size]))
        res_y_4.append(aggregator(y_4[i:i+window_size]))
    return [res_x, np.array(res_y_1), np.array(res_y_2), np.array(res_y_3), np.array(res_y_4)]


def load_latency(filename):
    with open(filename) as manager_log_file:
        lines = manager_log_file.readlines()
        x = [int(x.split()[1][1:-1]) for x in lines if "Invocation timestamps:" in x]
        strt_timestamps = [int(x.split()[5]) for x in lines if "Invocation timestamps:" in x]
        recv_timestamps = [int(x.split()[6]) for x in lines if "Invocation timestamps:" in x]
        resp_timestamps = [int(x.split()[7]) for x in lines if "Invocation timestamps:" in x]
        fini_timestamps = [int(x.split()[8]) for x in lines if "Invocation timestamps:" in x]
        return [x, np.array(strt_timestamps), np.array(recv_timestamps), np.array(resp_timestamps), np.array(fini_timestamps)]



gos    = load_latency("gos_manager.log")

gos    = sliding_window(gos,    25, statistics.mean)

matplotlib.rcParams.update({'font.size': 16})
plt.rcParams["figure.figsize"] = (10, 4)
plt.plot(gos[0],    gos[FINI_IDX] - gos[STRT_IDX],    linestyle = "-",                                               linewidth = 3, label = "Total")
plt.plot(gos[0],    gos[RECV_IDX] - gos[STRT_IDX],    linestyle = ":",                                               linewidth = 3, label = "Send")
plt.plot(gos[0],    gos[RESP_IDX] - gos[RECV_IDX],    linestyle = "--",                                              linewidth = 3, label = "Process")
plt.plot(gos[0],    gos[FINI_IDX] - gos[RESP_IDX],    linestyle = ":",                                               linewidth = 3, label = "Receive")
plt.xlabel("Time (s)")
plt.ylabel("Latency")
# plt.yscale('log')
plt.grid()
plt.xlim(xmin=0)
# plt.ylim(ymin=0)
plt.legend(ncol=2, loc='upper right')
plt.tight_layout()
# plt.savefig("finegrained_latency.pdf")
plt.savefig("finegrained_latency.png", dpi=300, bbox_inches="tight")
plt.show()
