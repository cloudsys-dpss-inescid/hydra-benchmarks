#!/bin/bash

function DIR {
    echo "$(cd "$(dirname "${BASH_SOURCE[0]}")" &>/dev/null && pwd)"
}

for f in $(DIR)/*.py; do
  python3 "$f"
done
