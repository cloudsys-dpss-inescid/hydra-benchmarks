#!/usr/bin/python

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import json
import statistics


def sliding_window(input, window_size, aggregator):
    x = input[0]
    y = input[1]
    res_x = []
    res_y = []
    for i in range(len(x) - window_size + 1):
        res_x.append(x[i])
        res_y.append(aggregator(y[i:i+window_size]))
    return [res_x, res_y]


def load_lambdas(filename):
    with open(filename) as metrics_file:
        dataset = json.load(metrics_file)
        timestamps = [x["timestamp"] / 1000 for x in dataset]
        active_lambdas = [x["open_requests"] for x in dataset]
        return [timestamps, active_lambdas]


gv    = load_lambdas("gv_metrics.log")
gv_sf    = load_lambdas("gv-sf_metrics.log")
gv_si    = load_lambdas("gv-si_metrics.log")
ow    = load_lambdas("ow_metrics.log")

gv    = sliding_window(gv,    10, statistics.mean)
gv_sf    = sliding_window(gv_sf,    10, statistics.mean)
gv_si    = sliding_window(gv_si,    10, statistics.mean)
ow    = sliding_window(ow,    10, statistics.mean)

matplotlib.rcParams.update({'font.size': 16})
plt.rcParams["figure.figsize"] = (10, 4)
plt.plot(gv[0],    gv[1],    linestyle = "-",                                               linewidth = 3, label = "Hydra")
plt.plot(gv_sf[0],    gv_sf[1],    linestyle = "--",                                               linewidth = 3, label = "Hydra-SF")
plt.plot(gv_si[0],    gv_si[1],    linestyle = ":",                                               linewidth = 3, label = "Hydra-SI")
plt.plot(ow[0],    ow[1],    linestyle = "-",                                               linewidth = 3, label = "OpenWhisk")
plt.xlabel("Time (s)")
plt.ylabel("Busy Slots in LM")
# plt.yscale('log')
plt.grid()
# plt.xlim(xmin=0, xmax=1200)
plt.legend(ncol=2, loc='upper right')
plt.tight_layout()
# plt.savefig("slots.pdf")
plt.savefig("slots.png", dpi=300, bbox_inches="tight")
plt.show()
