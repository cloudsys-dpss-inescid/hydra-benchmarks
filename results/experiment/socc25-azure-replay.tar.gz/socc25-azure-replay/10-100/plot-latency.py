#!/usr/bin/python

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import json


def load_latency(filename):
    with open(filename) as manager_log_file:
        lines = manager_log_file.readlines()
        lines = [x for x in lines if "FINE Time" in x]
        latencies = [x.split("req: ", 1)[1].split(";", 1)[0] for x in lines]
        return [float(x) / 1000 for x in latencies]


gv    = load_latency("gv_manager.log")
gv_sf    = load_latency("gv-sf_manager.log")
gv_si    = load_latency("gv-si_manager.log")
ow    = load_latency("ow_manager.log")

x_gv    = np.sort(gv)
x_gv_sf    = np.sort(gv_sf)
x_gv_si    = np.sort(gv_si)
x_ow    = np.sort(ow)

y_gv    = np.arange(len(gv)) / float(len(gv))
y_gv_sf    = np.arange(len(gv_sf)) / float(len(gv_sf))
y_gv_si    = np.arange(len(gv_si)) / float(len(gv_si))
y_ow    = np.arange(len(ow)) / float(len(ow))

matplotlib.rcParams.update({'font.size': 16})
plt.rcParams["figure.figsize"] = (10, 4)
plt.plot(x_gv,    y_gv,    linestyle = "-",                                               linewidth = 3, label = "Hydra")
plt.plot(x_gv_sf,    y_gv_sf,    linestyle = "--",                                               linewidth = 3, label = "Hydra-SF")
plt.plot(x_gv_si,    y_gv_si,    linestyle = ":",                                               linewidth = 3, label = "Hydra-SI")
plt.plot(x_ow,    y_ow,    linestyle = "-",                                               linewidth = 3, label = "OpenWhisk")
plt.xscale('log')
plt.ylim(ymin=0, ymax=1)
plt.xlim(xmin=0, xmax=1000)
plt.xlabel("User Request Latency (ms)")
plt.ylabel("CDF")
plt.grid()
plt.legend(ncol=2, loc='lower right')
plt.tight_layout()
# plt.savefig("latency.pdf")
plt.savefig("latency.png", dpi=300, bbox_inches="tight")
plt.show()
