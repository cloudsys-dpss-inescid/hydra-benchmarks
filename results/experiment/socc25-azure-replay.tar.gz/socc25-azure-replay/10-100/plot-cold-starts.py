#!/usr/bin/python

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import json
import statistics


def sliding_window(input, window_size, aggregator):
    x = input[0]
    y = input[1]
    res_x = []
    res_y = []
    for i in range(len(x) - window_size + 1):
        res_x.append(x[i])
        res_y.append(aggregator(y[i:i+window_size]))
    return [res_x, res_y]


def load_latency(filename):
    with open(filename) as manager_log_file:
        lambda_startup_timestamps = [int(x.split(' ')[1][1:-1]) for x in manager_log_file.readlines() if "Obtained a new lambda from the pool." in x]
        timestamps = np.arange(0, lambda_startup_timestamps[-1] + 1000, 1000)
        cold_starts = np.histogram(lambda_startup_timestamps, bins=timestamps)[0]
        return [timestamps[1:], cold_starts]


# gv    = load_latency("gv_manager.log")
# gv_sf    = load_latency("gv-sf_manager.log")
# gv_si    = load_latency("gv-si_manager.log")
ow    = load_latency("ow_manager.log")

# gos    = sliding_window(gos,    25, statistics.mean)

matplotlib.rcParams.update({'font.size': 16})
plt.rcParams["figure.figsize"] = (10, 4)
# plt.plot(gv[0],    gv[1],    linestyle = "-",                                               linewidth = 3, label = "Hydra")
# plt.plot(gv_sf[0],    gv_sf[1],    linestyle = "--",                                               linewidth = 3, label = "Hydra-SF")
# plt.plot(gv_si[0],    gv_si[1],    linestyle = ":",                                               linewidth = 3, label = "Hydra-SI")
plt.plot(ow[0],    ow[1],    linestyle = "-",                                               linewidth = 3, label = "OpenWhisk")
plt.xlabel("Time (s)")
plt.ylabel("Number of Pool Fetches")
# plt.yscale('log')
plt.grid()
# plt.xlim(xmin=0, xmax=1200)
plt.legend(ncol=2, loc='upper right')
plt.tight_layout()
# plt.savefig("cold_starts.pdf")
# plt.savefig("cold-starts.png", dpi=300, bbox_inches="tight")
plt.show()
