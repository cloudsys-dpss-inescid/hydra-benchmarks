#!/usr/bin/python

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import json
import statistics


PERIOD = 60000
x_labels = ["Hot", "Warm", "Cold"]

def load_all(filename):
    with open(filename) as manager_log_file:
        lambda_startup_timestamps = [int(x.split(' ')[1][1:-1]) for x in manager_log_file.readlines() if "Found lambda " in x]
        timestamps = np.arange(0, lambda_startup_timestamps[-1] + PERIOD, PERIOD)
        cold_starts = np.histogram(lambda_startup_timestamps, bins=timestamps)[0]
        return [timestamps[1:], cold_starts]

def load_hot(filename):
    all = load_all(filename)
    warm = load_warm(filename)
    warm[1] = np.hstack([warm[1], np.zeros(len(all[1]) - len(warm[1]), dtype=int)])
    return [all[0], all[1] - warm[1]]

def load_warm(filename):
    with open(filename) as manager_log_file:
        lambda_startup_timestamps = [int(x.split(' ')[1][1:-1]) for x in manager_log_file.readlines() if "Obtained a new lambda from the pool." in x]
        timestamps = np.arange(0, lambda_startup_timestamps[-1] + PERIOD, PERIOD)
        cold_starts = np.histogram(lambda_startup_timestamps, bins=timestamps)[0]
        return [timestamps[1:], cold_starts]

def load_cold(filename):
    with open(filename) as manager_log_file:
        lambda_startup_timestamps = [int(x.split(' ')[1][1:-1]) for x in manager_log_file.readlines() if " It took " in x]
        timestamps = np.arange(0, lambda_startup_timestamps[-1] + PERIOD, PERIOD)
        cold_starts = np.histogram(lambda_startup_timestamps, bins=timestamps)[0]
        return [timestamps[1:], cold_starts]


gv_hot    = load_hot("gv_manager.log")
gv_sf_hot    = load_hot("gv-sf_manager.log")
gv_si_hot    = load_hot("gv-si_manager.log")
ow_hot    = load_hot("ow_manager.log")

gv_warm    = load_warm("gv_manager.log")
gv_sf_warm    = load_warm("gv-sf_manager.log")
gv_si_warm    = load_warm("gv-si_manager.log")
ow_warm    = load_warm("ow_manager.log")

gv_cold    = load_cold("gv_manager.log")
gv_sf_cold    = load_cold("gv-sf_manager.log")
gv_si_cold    = load_cold("gv-si_manager.log")
ow_cold    = load_cold("ow_manager.log")

gv =    [[np.mean(gv_hot[1]),    np.mean(gv_warm[1]),    np.mean(gv_cold[1])],    [np.std(gv_hot[1]),    np.std(gv_warm[1]),    np.std(gv_cold[1])]]
gv_sf =    [[np.mean(gv_sf_hot[1]),    np.mean(gv_sf_warm[1]),    np.mean(gv_sf_cold[1])],    [np.std(gv_sf_hot[1]),    np.std(gv_sf_warm[1]),    np.std(gv_sf_cold[1])]]
gv_si =    [[np.mean(gv_si_hot[1]),    np.mean(gv_si_warm[1]),    np.mean(gv_si_cold[1])],    [np.std(gv_si_hot[1]),    np.std(gv_si_warm[1]),    np.std(gv_si_cold[1])]]
ow =    [[np.mean(ow_hot[1]),    np.mean(ow_warm[1]),    np.mean(ow_cold[1])],    [np.std(ow_hot[1]),    np.std(ow_warm[1]),    np.std(ow_cold[1])]]

x = np.arange(len(x_labels))
width = 0.15

matplotlib.rcParams.update({'font.size': 16})
plt.rcParams["figure.figsize"] = (10, 4)
# fig, ax = plt.subplots()
plt.bar(x + 0*width,  gv[0],    yerr=gv[1],   width=width, hatch='*', label='Hydra',     alpha=0.75)
plt.bar(x + 0*width,  gv_sf[0],    yerr=gv_sf[1],   width=width, hatch='0', label='Hydra-SF',     alpha=0.75)
plt.bar(x + 0*width,  gv_si[0],    yerr=gv_si[1],   width=width, hatch='*', label='Hydra-SI',     alpha=0.75)
plt.bar(x + 0*width,  ow[0],    yerr=ow[1],   width=width, hatch='0', label='OpenWhisk',     alpha=0.75)

plt.ylabel('Worker Starts')
plt.xlabel('Mode')
plt.xticks(x + 1.5 * width, x_labels)
# plt.axisbelow(True)
plt.grid(axis = 'y', linestyle = '--', linewidth = 0.25)
# plt.xticks(rotation = 35)
plt.yscale('log')
# ax.set_xlim(xmin=-.25, xmax=14.7)
plt.ylim(ymin=0)

plt.legend(ncol=2, loc='upper center')
plt.tight_layout()
# plt.savefig("starts.pdf", bbox_inches='tight')
plt.savefig("starts.png", dpi=300, bbox_inches='tight')
plt.show()
