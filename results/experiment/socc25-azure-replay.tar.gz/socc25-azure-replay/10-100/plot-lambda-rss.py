#!/usr/bin/python

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import json


def load_rss(filename):
    with open(filename) as manager_log_file:
        lines = manager_log_file.readlines()
        lines = [x for x in lines if "Maximum resident set size" in x]
        footprints = [x.split()[-1] for x in lines]
        return [int(x) for x in footprints]


gos    = load_rss("gos_lambda_rss.log")

x_gos    = np.sort(gos)

y_gos    = np.arange(len(gos)) / float(len(gos))

matplotlib.rcParams.update({'font.size': 16})
plt.rcParams["figure.figsize"] = (10, 4)
plt.plot(x_gos,    y_gos,    linestyle = ":",                                               linewidth = 3, label = "GraalOS")
# plt.xscale('log')
plt.ylim(ymin=0, ymax=1)
plt.xlim(xmin=0)
plt.xlabel("Max RSS (kbytes)")
plt.ylabel("CDF")
plt.grid()
plt.legend(ncol=2, loc='lower right')
plt.tight_layout()
# plt.savefig("lambda_rss.pdf")
plt.savefig("lambda_rss.png", dpi=300, bbox_inches="tight")
plt.show()
