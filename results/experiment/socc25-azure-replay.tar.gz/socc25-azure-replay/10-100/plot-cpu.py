#!/usr/bin/python

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import json
import statistics


def sliding_window(input, window_size, aggregator):
    x = input[0]
    y = input[1]
    res_x = []
    res_y = []
    for i in range(len(x) - window_size + 1):
        res_x.append(x[i])
        res_y.append(aggregator(y[i:i+window_size]))
    return [res_x, res_y]


def load_lambdas(filename):
    with open(filename) as metrics_file:
        dataset = json.load(metrics_file)
        timestamps = [x["timestamp"] / 1000 for x in dataset]
        user_cpu = [x["user_cpu"] for x in dataset]
        system_cpu = [x["system_cpu"] for x in dataset]
        return [timestamps, user_cpu, system_cpu, (np.array(user_cpu) + np.array(system_cpu))]


gos    = load_lambdas("gos_metrics.log")

# gos    = sliding_window(gos,    10, statistics.mean)

matplotlib.rcParams.update({'font.size': 16})
plt.rcParams["figure.figsize"] = (10, 4)
plt.plot(gos[0],    gos[1],    linestyle = ":",                                               linewidth = 3, label = "User")
plt.plot(gos[0],    gos[2],    linestyle = "--",                                              linewidth = 3, label = "System")
plt.plot(gos[0],    gos[3],    linestyle = "-",                                               linewidth = 3, label = "Total")
plt.xlabel("Time (s)")
plt.ylabel("CPU Utilization (%)")
# plt.yscale('log')
plt.grid()
plt.xlim(xmin=0)
plt.ylim(ymin=0)
plt.legend(ncol=2, loc='upper right')
plt.tight_layout()
# plt.savefig("cpus.pdf")
plt.savefig("cpus.png", dpi=300, bbox_inches="tight")
plt.show()
