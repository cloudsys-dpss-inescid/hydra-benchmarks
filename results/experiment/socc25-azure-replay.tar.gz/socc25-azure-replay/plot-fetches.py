#!/usr/bin/python

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import json
import statistics


PERIOD = 60000
x_labels = ["Warm", "Cold"]

def load_all(filename):
    with open(filename) as manager_log_file:
        all_starts = len([x for x in manager_log_file.readlines() if "Found lambda " in x])
        return all_starts

def load_hot(filename):
    all = load_all(filename)
    warm = load_warm(filename)
    return all - warm


def load_warm(filename):
    if "ow" in filename or "kn" in filename:
        return 0
    else:
        with open(filename) as manager_log_file:
            warm_starts = len([x for x in manager_log_file.readlines() if "Obtained a new lambda from the pool." in x])
            return warm_starts


def load_cold(filename):
    if "ow" in filename or "kn" in filename:
        with open(filename) as manager_log_file:
            warm_starts = len([x for x in manager_log_file.readlines() if "Obtained a new lambda from the pool." in x])
            return warm_starts
    with open(filename) as manager_log_file:
        cold_starts = len([x for x in manager_log_file.readlines() if "(cold start)" in x])
        return cold_starts


# hi_gv_hot    = load_hot("hi/gv_manager.log")
# # hi_gv_si_hot = load_hot("hi/gv-si_manager.log")
# hi_kn_hot    = load_hot("hi/kn_manager.log")
# hi_gv_fc_hot = load_hot("hi/gv-fc_manager.log")
# hi_ow_hot    = load_hot("hi/ow_manager.log")

hi_gv_warm    = load_warm("hi/gv_manager.log")
# hi_gv_si_warm = load_warm("hi/gv-si_manager.log")
hi_kn_warm    = load_warm("hi/kn_manager.log")
hi_gv_fc_warm = load_warm("hi/gv-fc_manager.log")
hi_ow_warm    = load_warm("hi/ow_manager.log")

hi_gv_cold    = load_cold("hi/gv_manager.log")
# hi_gv_si_cold = load_cold("hi/gv-si_manager.log")
hi_kn_cold    = load_cold("hi/kn_manager.log")
hi_gv_fc_cold = load_cold("hi/gv-fc_manager.log")
hi_ow_cold    = load_cold("hi/ow_manager.log")

hi_gv =    [hi_gv_warm,    hi_gv_cold]
# hi_gv_si = [hi_gv_si_warm, hi_gv_si_cold]
hi_kn    = [hi_kn_warm, hi_kn_cold]
hi_gv_fc = [hi_gv_fc_warm, hi_gv_fc_cold]
hi_ow =    [hi_ow_warm,    hi_ow_cold]


# lo_gv_hot    = load_hot("lo/gv_manager.log")
# # lo_gv_si_hot = load_hot("lo/gv-si_manager.log")
# lo_kn_hot    = load_hot("lo/kn_manager.log")
# lo_gv_fc_hot = load_hot("lo/gv-fc_manager.log")
# lo_ow_hot    = load_hot("lo/ow_manager.log")

lo_gv_warm    = load_warm("lo/gv_manager.log")
# lo_gv_si_warm = load_warm("lo/gv-si_manager.log")
lo_kn_warm    = load_warm("lo/kn_manager.log")
lo_gv_fc_warm = load_warm("lo/gv-fc_manager.log")
lo_ow_warm    = load_warm("lo/ow_manager.log")

lo_gv_cold    = load_cold("lo/gv_manager.log")
# lo_gv_si_cold = load_cold("lo/gv-si_manager.log")
lo_kn_cold    = load_cold("lo/kn_manager.log")
lo_gv_fc_cold = load_cold("lo/gv-fc_manager.log")
lo_ow_cold    = load_cold("lo/ow_manager.log")

lo_gv =    [lo_gv_warm,    lo_gv_cold]
# lo_gv_si = [lo_gv_si_warm, lo_gv_si_cold]
lo_kn    = [lo_kn_warm, lo_kn_cold]
lo_gv_fc = [lo_gv_fc_warm, lo_gv_fc_cold]
lo_ow =    [lo_ow_warm,    lo_ow_cold]


x = np.arange(len(x_labels))
width = 0.15

matplotlib.rcParams.update({'font.size': 16})

fig, (ax1, ax2) = plt.subplots(1, 2, sharey=True)

ax1.bar(x + 0*width,  lo_ow,     width=width, hatch='/', label='OpenWhisk', alpha=0.75)
# ax1.bar(x + 1*width,  lo_gv_si,  width=width, hatch='.', label='Hydra SI',  alpha=0.75)
ax1.bar(x + 2*width,  lo_kn,  width=width, hatch='O', label='Knative',  alpha=0.75)
ax1.bar(x + 3*width,  lo_gv,     width=width, hatch='*', label='Hydra',  alpha=0.75)
ax1.bar(x + 4*width,  lo_gv_fc,  width=width, hatch='.', label='Hydra*',  alpha=0.75)

ax1.set_ylabel('Worker Starts')
ax1.set_xlabel('Node #1')
ax1.set_xticks(x + 1.5 * width, x_labels)
ax1.grid(axis = 'y', linestyle = '--', linewidth = 0.25)
ax1.set_yscale('log')
ax1.set_ylim(ymin=0, ymax=9000000)
ax1.legend(ncol=1, loc='upper right')

ax2.bar(x + 0*width,  hi_ow,     width=width, hatch='/', label='OpenWhisk', alpha=0.75)
# ax2.bar(x + 1*width,  hi_gv_si,  width=width, hatch='.', label='Hydra SI',  alpha=0.75)
ax2.bar(x + 2*width,  hi_kn,  width=width, hatch='O', label='Knative',  alpha=0.75)
ax2.bar(x + 3*width,  hi_gv,     width=width, hatch='*', label='Hydra',  alpha=0.75)
ax2.bar(x + 4*width,  hi_gv_fc,  width=width, hatch='.', label='Hydra*',  alpha=0.75)

ax2.set_xlabel('Node #2')
ax2.set_xticks(x + 1.5 * width, x_labels)
ax2.grid(axis = 'y', linestyle = '--', linewidth = 0.25)
ax2.set_yscale('log')
ax2.set_ylim(ymin=0, ymax=9000000)

fig.set_figwidth(10)
fig.set_figheight(4)

fig.text(0.5, -0.02, 'Mode', ha='center')

# plt.legend(ncol=1, loc='upper right')
plt.savefig("starts.pdf", bbox_inches='tight')
plt.savefig("starts.png", dpi=300, bbox_inches='tight')
# plt.show()

print("LO (Node #1) Cold Hydra: " + str(lo_gv[1]))
print("LO (Node #1) Cold Hydra*: " + str(lo_gv_fc[1]))
print("LO (Node #1) Cold OW: " + str(lo_ow[1]))
print("LO (Node #1) Cold Knative: " + str(lo_kn[1]))

print("LO (Node #1) Warm Hydra: " + str(lo_gv[0]))
print("LO (Node #1) Warm Hydra*: " + str(lo_gv_fc[0]))
print("LO (Node #1) Warm OW: " + str(lo_ow[0]))
print("LO (Node #1) Warm Knative: " + str(lo_kn[0]))

print("HI (Node #2) Cold Hydra: " + str(hi_gv[1]))
print("HI (Node #2) Cold Hydra*: " + str(hi_gv_fc[1]))
print("HI (Node #2) Cold OW: " + str(hi_ow[1]))
print("HI (Node #2) Cold Knative: " + str(hi_kn[1]))

print("HI (Node #2) Warm Hydra: " + str(hi_gv[0]))
print("HI (Node #2) Warm Hydra*: " + str(hi_gv_fc[0]))
print("HI (Node #2) Warm OW: " + str(hi_ow[0]))
print("HI (Node #2) Warm Knative: " + str(hi_kn[0]))

# min_gv = min(lo_gv[1], lo_gv_fc[1])
# ow = lo_ow[1]
# print("Reduced warm starts in Node#1:")
# print(ow / min_gv)

# min_gv = min(hi_gv[1], hi_gv_fc[1])
# ow = hi_ow[1]
# print("Reduced warm starts in Node#2:")
# print(ow / min_gv)
